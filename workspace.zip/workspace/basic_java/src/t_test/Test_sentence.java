package t_test;

import java.util.Scanner;

public class Test_sentence {
//전역변수		int a = 10;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//지역변수
//		int[][] arr = {
//				{ 5, 8, 13, 5, 2 },
//				{ 22, 13, 28 },
//				{ 2, 18, 23, 62 }
//			  };
//		int total = 0;	// 총 합계 저장 변수
//		float average = 0; 	//평균 변수
//	
//		int index=0;
//		for(int i =0; i<arr.length; i++){
//			for(int j = 0; j< arr[i].length; j++){
//				total += arr[i][j];
//			}
//			index += arr[i].length;
//		}
//		average = ((int)((float)total/index*100+0.5))/100f;
//	
//				
//		System.out.println("total = "+total);
//		System.out.println("Average = "+average);
//		
//		args[0];	// "3170"
//		int a = Integer.parseInt(args[0]);
//		System.out.println(args[0]);

//				 클래스 ------------변수
//					|		|
//		  인스턴스화	|		|
//		  			|		|___ 메서드
//		  		 인스턴스
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
