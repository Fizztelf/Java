package y_project;

public class MainClass {

	public static void main(String[] args) {
		
		View v = new View();
		v.startMethod();

	}

}
