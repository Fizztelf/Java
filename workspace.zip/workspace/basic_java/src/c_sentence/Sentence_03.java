package c_sentence;

import java.util.Scanner;

public class Sentence_03 {

	public static void main(String[] args) {
		
		/*
		1. 사용자로부터 값을 입력받기
		  - Scanner
		*/
		
		Scanner sc = new Scanner(System.in);
//		System.out.println("문자열을 입력해주세요");
//		String input = sc.nextLine();
//		System.out.println(input);
//		
//		System.out.println("숫자를 입력해주세요");
//		int input = sc.nextInt();
//		System.out.println("입력하신 숫자는 "+input+"입니다");
		
		//1. 사용자로부터 숫자 두개를 받아서 두 숫자 사이의 합을 출력해주세요
		
		
//		Scanner sc = new Scanner(System.in);
//		System.out.println("첫 번째 숫자를 입력해주세요");
//		int input = sc.nextInt();
//		System.out.println("두 번째 숫자를 입력해주세요");
//		int input1 = sc.nextInt();
//		
//		//시작 : input , 끝 : input1, 증가량 : 1 , 반복구문 : sum += ?;
//		
//		int sum = 0;
//		for(int num = input; num < input1+1; num++) {
//			sum += num;
//		}
//		System.out.println("더 해주면 : " + sum + " 이다");
		
		
		//계산기를 만들어오세영..?	break;,,, 두 와일
		
		
		/*
		2. do-while
		  - while문의 변형으로 기본구조는 while문과 비슷하다
		  	하지만 최소 1회는 블럭{}을 수행하게 된다.
		  - 기본구조
		  	do{
		  		수행될 문장
		  	} while(조건식);
		
		*/
		
		//사용자로부터 입력받은 문자열을 출력하는 프로그램 만든다.
		//단, 사용자가 "exit" 입력할 때까지의 무한 반복하게 하라.
//		String input3 = "";
//		do{
//			System.out.println("문자열을 입력해주세요");
//			input3 = sc.next();
//			System.out.println(input3);
//		} while(!"exit".equals(input3));
		
		//1. 사용자로부터  숫자를 입력받는다.
//		String buho = "";
//		do {
//		System.out.println("첫 번째 숫자를 입력해주세요");
//		int input11 = sc.nextInt();
//		//2. 사용자로부터 부호를 입력받는다.
//		System.out.println("부호를 입력해주세요");
//		buho = sc.next();
////		if(buho != "+,-,*,%"){
////			break;
////		}
//		//3. 사용자로부터 숫자를 입력받는다.
//		System.out.println("첫 번째 숫자를 입력해주세요");
//		int input13 = sc.nextInt();
//		//4. 연산을 수행하여 결과를 출력한다.
//		
//			if("+".equals(buho)){
//				int result = input11+input13;
//				System.out.println("더하기 : " + result);
//			} else if("-".equals(buho)) {
//				int result = input11-input13;
//				System.out.println("빼기 : " + result);
//			} else if("*".equals(buho)){
//				int result = input11*input13;
//				System.out.println("곱하기 : " + result);
//			} else if("/".equals(buho)){
//				int result = input11/input13;
//				System.out.println("나누기 : " + result);
//			} else {
//				buho = "esc";
//				System.out.println("부호를 잘못입력하여 종료하겠습니다!");
//			}
////				
//		} while(!"esc".equals(buho));
//		
//		//5. 1~4를 무한 반복해준다.
//		// 단, 사용자가 입력한 부호가 사칙연산자가 아니면 종료하여라
		
		
		
		
//		do{
//			System.out.println("숫자1 입력하시오");
//			int firNum = sc.nextInt();
//			System.out.println("사직연산");
//			String buho = sc.next();
//			System.out.println("숫자2 입력하시오");
//			int secNum = sc.nextInt();
//			
//			if("+".equals(buho)){
//				System.out.println(firNum+secNum);
//			} else if ("-".equals(buho)){
//				System.out.println(firNum-secNum);
//			} else if ("*".equals(buho)){
//				System.out.println(firNum*secNum);
//			} else if ("/".equals(buho)){
//				System.out.println((int)(float)firNum/secNum*100+0.5/100f);
//			}else{
//				System.out.println("사칙연산 아님, 종료!");
//				break;
//			}
//		}while(true);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
