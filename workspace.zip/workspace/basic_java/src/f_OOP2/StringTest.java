package f_OOP2;

public class StringTest {
	public static void main(String[] args) {
		
		String s = new String("hello");
		s = "hello";
		char c = s.charAt(1);		// hello 에서 0 1 2 3 4 5 순서니까 1번째에 있는 문자열 출력
		System.out.println(c);
		
		int i = "aaa".compareTo("aaa");		// 문자열이 같으면 0
		int i2 = "aaa".compareTo("aab");	// 문자열이 다르면 -1
		
		System.out.println(i);
		System.out.println(i2);
		
		String s1 = "Hello";
		String s2 =  s1.concat(" Oracle");	// s1 에 있는 hello 에서 oracle을 붙여서 출력
		System.out.println(s2);
		
		String s3 = "JavaSoEz";
		boolean b = s3.contains("S");		//s3에  "S"라는 문자열을 갖고 있는가? 있으면 true, 아니면 false
		System.out.println(b);
		
		String s4 = "JavaSoEz, java";
		boolean b1 = s4.endsWith("java");		//s4에  문자열 끝에가 "java"로 끝나는가? 맞으면 true, 아니면 false
		System.out.println(b1);
		
		String s5 = "Java";
		boolean b2 = s5.equals("java");		//s5와 b2의 문자열이  같으면 ture, 다르면 false
		System.out.println(b2);
		
		String s6 = "Hello";
		int bb = s6.indexOf("l");		// s6에서 가지고 있는 문자열중에 l의 위치를 알려준다. 
		System.out.println(bb);			// 만약 o의 위치를 알고 싶다면 int bb = s6.indexOf("o"); 해주면 답은 4가 나온다
		
		String s7 = "Hello";
		int bb1 = s7.lastIndexOf("l"); 		// s7에서 가지고 있는 문자열 맨 끝에서 부터 l의 위치를 찾는다
		System.out.println(bb1);
		
		String s8 = "My Length";
		int bb2 = s8.length();			// s8에서의 문자열 길이를 알려준다(띄어쓰기 포함)
		System.out.println(bb2);
		
		
		String s9 = "Hello Oracle";					
		String ss = s9.replace("Oracle", "Java");		// (old, new)순서인데, ss에서 old가 Oracle이고 이것을 새로운 new 문자열로 바꾸고 출력
		System.out.println(ss);
		
		
		String s10 = "dog-cat-snake";
		String[] sArr = s10.split("-");		// s10의 문자열에서 "-" 를 제외한 문자열을 배열에 담아서 반환
		System.out.println(sArr[0]);
		System.out.println(sArr[1]);
		System.out.println(sArr[2]);
		
		
		String s11 = "I Love Java";
		String s12 = s11.substring(2, 6);		//문자열에서 2번째, 6번째 사이의 문자열을 출력
		System.out.println(s12);
		
		String s13 = s11.toLowerCase();		//모든 문자열을 소문자로 변환
		System.out.println(s13);
		
		String s14 = s11.toUpperCase();		//모든 문자열을 대문자로 변환
		System.out.println(s14);
		
		
		String s15 = "  My   Trim   ";
		String s16 = s15.trim();			//문자열의 왼쪽 끝과 오른쪽 끝에 있는 공백을 없앤 결과를 반환, 하지만 문자열 중간에 있는 공백은 제거 안됨
		System.out.println(s16);
		
		String a1 = String.valueOf(true);
		String a2 = String.valueOf(100);		//지정된 값을 문자열로 반환
		String a3 = String.valueOf('a');
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		
		
		
		
	}
}
