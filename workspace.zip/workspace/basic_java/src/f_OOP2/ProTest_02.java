package f_OOP2;

public class ProTest_02 {
	public int a = 10;
	protected int b = 20;
	int c = 30;
	private int d = 40;
}
