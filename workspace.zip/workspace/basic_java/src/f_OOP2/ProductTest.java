package f_OOP2;

import java.util.Vector;

public class ProductTest {
	public static void main(String[] args) {
		
		//맥북 300
		NoteBook nb = new NoteBook("맥북", 300);
		
		//스타일러 200
		Styler st = new Styler("LG", 200);
		
		//냉장고는 500
		Fridge f = new Fridge("SAMSUNG", 500);
		
		//고객 입장
		Buyer b = new Buyer("준", 1000);
		
		
		
		//쇼핑
		
		b.buy(nb);
		b.buy(st);
		
		b.summary();
//		System.out.println("\t"+"영    수    증");
//		System.out.println();
//		System.out.println("\t"+"구매목록");
//		System.out.println();
//		System.out.println("\t"+nb+"\t\t"+nb.price+"만원");
//		System.out.println("\t"+f+"\t\t\t"+st.price+"만원");
//		System.out.println("\t"+"-------------------------------");
//		System.out.println("\t"+"총합금액"+"\t\t\t"+sum+"만원");
		
		
		
	}

	
}


class Product{
	//제품이름
	String name;
	//가격
	int price;
	//보너스 포인트(마일리지)
	int bonusPoint;
	
	public Product(String name, int price){
		this.name = name;
		this.price = price;
		bonusPoint = price/10;
	}
}

//class NoteBook extends Product{		기본생성자 타입
//	
//}

class NoteBook extends Product {
	NoteBook(String name, int price) {
		super(name, price);
	}

	@Override
	public String toString() {		// alt + shif + s  ==> s ==> enter
		return "NoteBook";
	}
}

class Styler extends Product{
	public Styler(String name , int price){
		super(name, price);
		
		
  }

	@Override
	public String toString() {
		return "Styler";
	}
}


class Fridge extends Product{
	public Fridge(String name, int price) {
		super(name, price);
		
		
	}

	@Override
	public String toString() {
		return "냉장고";
	}
}

class Buyer {
	String name;
	int money;
	int mileage;
	
	Vector item = new Vector();
	
	public Buyer(String name, int money) {
		this.name = name;
		this.money = money;
	}
	
	void buy(Product nb){
		if(money < nb.price){
			System.out.println("돈가져와");
			return;
		}
		money -= nb.price;
		mileage += nb.bonusPoint;
		item.add(nb);
		item.add(nb.price);
//		item.add(nb.name);
		
		
		System.out.println(name+"고객님 "+nb+"를 구매해 주셔서 감사합니다");
		
	}
	
	void summary(){
		
		
		System.out.println();
//		System.out.println(item.size());			//수량
		System.out.println("\t"+"영    수    증");
		System.out.println();
		System.out.println("\t"+"구매목록");
		System.out.println("\t"+item.get(0));
		System.out.println("\t"+item.get(2));
		System.out.println();
		System.out.println(name+" 고객님의 남은 돈은 "+ money +" 만원이고 마일리지는 "+this.mileage+" 입니다.");
	}
		
		
	
	

}
	
	
	//1. summary					item에서 꺼내왕.. 제품들
	/*
				영 수 증
		구매목록
		   NoteBook		300만원
		   Styler		200만원
		     총합			500만원
		xxx 고객님의 남은 돈은 xxx만원이고 마일리지는 xxx입니다
		오늘도 좋은 하루 보내십시오. 고갱님
	*/
	
	
	//2. refund
	/*
	1. 고려사항
	  - 물건을 산 내역이 없을 때
	  - 내가 산 물건만 반품
	*/
	
	
	
	
	
//	void buy(Styler nb){
//		if(money < nb.price){
//			System.out.println("돈가져와");
//			return;
//		}
//		money -= nb.price;
//		mileage += nb.bonusPoint;
//		System.out.println(name+"고객님"+nb+"를 구매해 주셔서 감사합니다");
//		
//	}
//	
//	void buy(Fridge nb){
//		if(money < nb.price){
//			System.out.println("돈가져와");
//			return;
//		}
//		money -= nb.price;
//		mileage += nb.bonusPoint;
//		System.out.println(name+"고객님"+nb+"를 구매해 주셔서 감사합니다");
//		
//	}
	







//3. 물품의 수량을 관리

//4. 고객들의 목록을 관리해주세요
































