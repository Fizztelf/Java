package e_OOP;





public class Ex3_2 {

	public static void main(String[] args) {
		

	}

}
