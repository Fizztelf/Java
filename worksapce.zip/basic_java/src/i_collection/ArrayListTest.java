package i_collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListTest {
	public static void main(String[] args) {
		
		List<Integer> list1 = new ArrayList<>();
		list1.add(new Integer(5));
		list1.add(2);
		list1.add(3);
		list1.add(1);
		list1.add(4);
	
		List<Integer> list2 = new ArrayList<>(list1.subList(1, 4));
		
		System.out.println(list1);		//주소가 나와야 되는데 값이 나옴. toString 메서드가 오버라이딩 되었다!
		System.out.println(list2);
	
		//R
		int a = list1.get(2); //언박싱
		System.out.println(a);
		
		//D
		list1.remove(2);  //  5 2 3 1 4
		System.out.println(list1); //3 제거
		
		//U
		int change = new Integer(10);
		int after = list1.set(1, change);	// 5 2 1 4
		System.out.println("바뀌기전 : " + after +", 바뀐 값 : "+ change);
		System.out.println(list1); // 5 10 1 4
		
		//그동안 정렬하느라 고생하셨습니다...
		// 정렬해주는 메서드가 있어요...
	
		Collections.sort(list1);		//컬렉션 중에 리스트만 된다.
		System.out.println(list1);
	
		
		
		
		
		
		
	
	
	
	
	
	
	
	
	
	
	}
}
