package h_javaLang;

public class StringBufferTest {
	public static void main(String[] args) {
		
		/*
		String str = "a";
		str += "a";
		str += "a";
		str += "a";
		str += "a";
			:
			
		String str = "a";
		str = new StringBuffer(str).append("a").toString();
		str = new StringBuffer(str).append("a").toString();
		str = new StringBuffer(str).append("a").toString();
		str = new StringBuffer(str).append("a").toString();
			:
		*/
		
//		String str = "a";
//		long start = System.currentTimeMillis();
//		for (int i = 0; i < 300000; i++) {
//			str += "a";
//		}
//		long end = System.currentTimeMillis();
//		System.out.println(end - start);
		
//		StringBuffer sb = new StringBuffer("a");		//Buffer는 동기화를 보장한다
//		long start = System.currentTimeMillis();
//		for (int i = 0; i < 300000000; i++) {
//			sb.append("a");
//		}
//		long end = System.currentTimeMillis();
//		System.out.println(end - start);
		
//		StringBuilder sb = new StringBuilder("a");		//Builder는 비동기, 사용할 수 있는 게 한정
//		long start = System.currentTimeMillis();
//		for (int i = 0; i < 300000000; i++) {
//			sb.append("a");
//		}
//		long end = System.currentTimeMillis();
//		System.out.println(end - start);
		
		
		
		
		
		
		
		
		
		
	}
}
