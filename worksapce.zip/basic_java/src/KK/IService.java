package KK;

import java.util.Map;

public interface IService {

	String lonIn(Map<String, String> params);
	int join(MemberVO mb);
	int revise(Map<String, String> params);
	int delete(Map<String, String> params);
	
	
}
