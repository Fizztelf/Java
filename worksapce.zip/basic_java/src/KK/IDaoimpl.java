package KK;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

public class IDaoimpl implements IDao {

	private int update;

	public boolean confimId(String resident_id) {
		boolean result = false;
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String Sid = "apt";
			String pw = "java";
			conn = DriverManager.getConnection(url, Sid, pw);
			st = conn.createStatement();
			String sql = "SELECT RESIDENT_ID FROM RESIDENT WHERE RESIDENT_ID ='"
					+ resident_id + "'";
			rs = st.executeQuery(sql);
			if (rs.next()) {
				result = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}

		return result;

	}

	@Override
	public String logIn(Map<String, String> params) {

		String resident_id = params.get("resident_id");
		String resident_pass = params.get("resident_pass");
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		int delpoint = 0;

		String logIn_ID = null;
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "apt";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

			String sql = "SELECT RESIDENT_ID " + "FROM  RESIDENT "
					+ "WHERE RESIDENT_ID ='" + resident_id
					+ "'AND RESIDENT_PASS ='" + resident_pass + "' AND RESIDENT_DELETE ='"+delpoint+"'";
			rs = st.executeQuery(sql);
			while (rs.next()) {
				logIn_ID = rs.getString("RESIDENT_ID");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return logIn_ID;
	}

	/**
	 * @author 박 찬
	 * @since 2020-09-07
	 * @see MemberVO에 입력받은 데이터의 저장값을 불러와 데이터 INSERT
	 */
	@Override
	public int join(MemberVO mb) {
		String resident_id = mb.getResident_id();
		String resident_pass = mb.getResident_pass();
		String resident_name = mb.getResident_name();
		int resident_addr = mb.getResident_addr();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		int updateCount = 0;
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "apt";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

			String sql = " INSERT INTO RESIDENT (RESIDENT_ID,RESIDENT_PASS,RESIDENT_NAME,RESIDENT_ADDR) "
					+ " VALUES ('"
					+ resident_id
					+ "','"
					+ resident_pass
					+ "','" + resident_name + "','" + resident_addr + "')";

			updateCount = st.executeUpdate(sql);
			if (updateCount == 1) {
				System.out.println("성공적으로 회원 가입완료 하였습니다.");

			} else {
				System.out.println("가입 실패하였습니다.");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return updateCount;

	}

	@Override
	public int revise(Map<String, String> params) {
		String mem_id = params.get("mem_id");
		String mem_pass = params.get("mem_pass");
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		int updateCount = 0;

		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "apt";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();
			String sql = "UPDATE RESIDENT SET RESIDENT_ID=";
			updateCount = st.executeUpdate(sql);
			if (updateCount == 1) {
				System.out.println("성공적으로 회원 가입완료 하였습니다.");

			} else {
				System.out.println("가입 실패하였습니다.");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}

		return revise(params);
	}
	
	@Override
	public int delete(Map<String, String> params) {
		String resident_id = params.get("resident_id");
		String inputPW = params.get("inputPW");
		String input = params.get("input");
		int updatecount = 0;
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "apt";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();
			String sql = "UPDATE RESIDENT "
					+ " SET RESIDENT_DELETE = '1'"
					+ " WHERE RESIDENT_ID = '"+resident_id+"'";
			st.executeUpdate(sql);
			if (updatecount!=1){
				System.out.println("삭제가 완료 되었습니다.");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return updatecount;
		
	}

}



