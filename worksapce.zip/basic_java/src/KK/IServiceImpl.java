package KK;

import java.util.Map;



public class IServiceImpl implements IService {
	
	private IDao dao = new IDaoimpl();
	

	@Override
	public String lonIn(Map<String, String> params) {
	
		
		return dao.logIn(params);
		//오라클 덤프
	}


	@Override
	public int join(MemberVO mb) {
		
		return dao.join(mb);
	}


	@Override
	public int revise(Map<String, String> params) {
		
		return dao.revise(params);
	}
	
	@Override
	public int delete(Map<String, String> params) {
		
		return dao.delete(params);
	}



}
