package KK;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ViewClass {
	private IService service = new IServiceImpl();
	private String login_id;
	private int login_join;

	// 시작시
	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 프로그램을 시작하는 메소드
	 * 
	 */
	void start() {
		while (true) {
			System.out.println("1.회원가입  2.입주민 로그인  3.방문객 4.관리자 로그인  5.종료");
			Scanner sc = new Scanner(System.in);
			int num = sc.nextInt();
			switch (num) {
			case 1:
				// 회원 가입
				create_id();
				break;
			case 2:
				// 입주민 로그인
				log_In();
				break;
			case 3:
				// 방문객
				visit_Log();
				break;
			case 4:
				// 관리자로그인
				manager_Login();
				break;

			case 5:
				// 종료
				System.out.println("프로그램이 종료됩니다.");
				System.exit(0);// 종료
			default:
				System.out.println("잘못 입력했습니다.");
				System.out.println("프로그램이 종료됩니다.");
				System.exit(0);// 종료
				break;
			}
		}
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 회원가입 시 입주민 관리자 선택하는 메서드
	 * 
	 */
	// 1. 회원가입
	private void create_id() {
		while (true) {
			System.out.println("1.입주민, 2.관리자, 3.뒤로가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 입주민 회원가입
				create_Citizen();
				break;
			case 2:
				// 관리자 회원가입
				create_Manager();
				break;
			case 3:
				return;
				// 뒤로가기
			default:
				System.out.println("잘못 입력하였습니다.");
				break;
			}
		}
	}

	/**
	 * 
	 * @author 박 찬
	 * @since 2020.09.07
	 * @param cheak
	 *            = IDaoimpl의 객체,mb = MemberVO 의 객체 ,success = boolean 타입의 중복 체크
	 *            성공 여부 판단의 변수
	 * @see 입주민 회원가입 메서드 ,입력 받은 값을 set을 통하여 MemberVO에 저장 IDaoimpl에있는
	 *      confimId()메소드를 통하여 입력한 아이디가 DB에 존재하는지 여부 값 result에 반환 하여 중복 체크한다. 중복
	 *      아이디 검사를 통하여 success를 통하여 do , while를 중복이면 아이디 입력 반복 중복이 아니면 비밀번호 입력
	 *      란 실행
	 **/
	// 1.1 입주민 회원가입
	private void create_Citizen() {
		MemberVO mb = new MemberVO();
		IDaoimpl cheak = new IDaoimpl();
		boolean success = false;

		// 아이디 입력
		// 비밀빈호 입력
		// 이름 입력
		// 동/호수 입력

		do {
			Scanner sc = new Scanner(System.in);
			System.out.println("아이디를 입력해주세요");
			String resident_id = sc.nextLine();

			if (cheak.confimId(resident_id) == false) {
				System.out.println("비밀번호를 입력해주세요");
				String resident_pass = sc.nextLine();

				System.out.println("거주자 이름을 입력해주세요");
				String resident_name = sc.next();

				System.out.println("동입력해주세요. ex)2동 103호 => 2103");
				int resident_addr = sc.nextInt();
				mb.setResident_addr(resident_addr);
				mb.setResident_id(resident_id);
				mb.setResident_pass(resident_pass);
				mb.setResident_name(resident_name);

				login_join = service.join(mb);
				success = true;
				start();

			} else {
				System.out.println("이미 존재하는 아이디입니다. \n다시입력해주세요.\n");

				success = false;

			}
		} while (success == false);

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 관리자 회원가입 메서드
	 * 
	 */
	// 1.2 관리자 회원가입
	private void create_Manager() {
		System.out.println("아직 구현 안됨 관리자 회원가입");

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 입주민이 로그인 하는 메서드
	 * 
	 */
	// 2. 입주민 로그인
	private void log_In() {
		// ID 입력
		// PW 입력
		Scanner sc = new Scanner(System.in);
		System.out.println("아이디를 입력해주세요");
		String resident_id = sc.next();

		System.out.println("비밀번호를 입력해주세요");
		String resident_pass = sc.next();
		Map<String, String> parms = new HashMap<>();
		parms.put("resident_id", resident_id);
		parms.put("resident_pass", resident_pass);

		login_id = service.lonIn(parms);

		// 로그아웃 null넣어야한다.

		if (login_id == null) {
			System.out.println("회원정보가 없습니다.");

		} else {
			System.out.println(resident_id + "회원님 어서오세요");
			citizen(resident_id, resident_pass);
		}

		// 로그인 구현 후 입주민 모드

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 입주민이 사용하는 페이지를 나타내는 메서드
	 * 
	 */
	// 2.1. 입주민 모드
	private void citizen(String resident_id, String resident_pass) {
		while (true) {
			System.out
					.println("1.차량조회, 2.게시판 , 3.관리비 확인, 4.우편물 확인  5.마이페이지 6.뒤로 가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 1.차량 조회
				car_Look();
				break;
			case 2:
				// 2.게시판
				community();
				break;
			case 3:
				// 3.관리비 확인
				expenses();
				break;
			case 4:
				// 4.우편물 확인
				delivery();
				break;
			case 5:
				// 마이페이지
				myPage(resident_id, resident_pass);
				break;
			case 6:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 입력 했습니다.");
				break;
			}
		}
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 입주민이 차량관련 기능을 사용하는 메서드
	 * 
	 */
	// 2.1.1. 차량 조회
	private void car_Look() {
		while (true) {
			System.out.println("1.차량 번호 확인, 2.주차위치확인, 3.뒤로가기 ");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 차량 번호 확인
				car_Num();
				break;
			case 2:
				// 주차 위치 확인
				car_Loc();
				break;
			case 3:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 차량번호를 확인하는 메서드
	 * 
	 */
	// 2.1.1.1.차량 번호 확인
	private void car_Num() {
		System.out.println("차량 확인 구현 안됨 ");

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 주차위치를 확인 하는 메서드
	 * 
	 */
	// 2.1.1.2.주차 위치 확인
	private void car_Loc() {
		System.out.println("주차확인 구현 안됨 ");

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 소통 게시판 메서드 회원은 민원글 작성 수정 삭제, 관리자는 댓글작성 삭제
	 * 
	 */
	// 2.1.2. 소통게시판
	private void community() {
		while (true) {
			// id는 임시로 해둔거 회원 관리자 구별 구현해야된다.
			int id = 0;
			// 회원일때
			if (id == 1) {
				System.out.println("1.민원글작성, 2.민원글수정, 3.민원글삭제, 4.뒤로가기");
				Scanner sc = new Scanner(System.in);
				int input = sc.nextInt();
				switch (input) {
				case 1:
					// 민원글 작성
					writing();
					break;
				case 2:
					// 민원글 수정
					edit();
					break;
				case 3:
					// 민원글 삭제
					delete();
					break;
				case 4:
					// 뒤로가기
					return;
				default:
					System.out.println("잘못 눌렀습니다.");
					break;
				}
			}
			// 관리자
			else if (id == 2) {
				System.out.println("1. 댓글 작성, 2.민원글삭제, 3.뒤로가기");
				Scanner sc = new Scanner(System.in);
				int input = sc.nextInt();
				switch (input) {
				case 1:
					// 민원글 댓글 작성
					comment();
					break;
				case 2:
					// 민원글 삭제
					delete();
					break;
				case 3:
					// 뒤로가기
					return;
				default:
					System.out.println("잘못 눌렀습니다.");
					break;
				}
			}

		}
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 게시판에 글 작성하는 메서드 작성은 거주민만 가능
	 * 
	 */
	// 2.1.2.1.민원글 작성(거주민)
	private void writing() {
		System.out.println("민원글작성  구현 안됨 ");
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 게시판에 글 수정하는 메서드 작성자만 해당 글을 수정 가능
	 * 
	 */
	// 2.1.2.2.민원글 수정(거주민)
	private void edit() {
		System.out.println("민원글수정  구현 안됨 ");

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 게시판에 글 삭제하는 메서드 본인 글만 삭제가능하고 관리자는 모든글 삭제가능
	 * 
	 */
	// 2.1.2.3.민원글 삭제
	private void delete() {
		System.out.println("민원글삭제 구현 안됨 ");

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 게시판에 댓글 작성하는 메서드, 관리자만 가능
	 * 
	 */
	// 2.1.2.4.민원글 댓글 작성(관리자)
	private void comment() {
		System.out.println("민원글댓글  구현 안됨 ");

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 관리비를 종류별로 확인하는 메서드 동호수별마다 관리해야된다.
	 * 
	 */
	// 2.1.3. 관리비 확인
	private void expenses() {
		while (true) {

			System.out.println("1.전기세, 2.수도세, 3.경비비, 4.뒤로가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 전기세 확인
				electrivity();
				break;
			case 2:
				// 수도세 확인
				water();
				break;
			case 3:
				// 경비비 확인
				guard();
				break;
			case 4:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 전기세를 확인하는 메서드 동호수별로 관리
	 * 
	 */
	// 2.1.3.1. 전기세
	private void electrivity() {
		System.out.println("전기세  구현 안됨 ");
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 수도세를 확인하는 메서드 동호수별로 관리
	 * 
	 */
	// 2.1.3.2. 수도세
	private void water() {
		System.out.println("수도세  구현 안됨 ");
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 경비비를 확인하는 메서드 동호수별로 관리
	 * 
	 */
	// 2.1.3.3. 경비비
	private void guard() {
		System.out.println("경비비  구현 안됨 ");
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 우편물의 여부를 확인하는 메서드 동호수별로 관리
	 * 
	 */
	// 2.1.4. 우편물 확인
	private void delivery() {
		System.out.println("우편함  구현 안됨 ");
		// citizen(resident_id);
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 우편물의 여부를 확인, 물품명 확인 하는 메서드 동호수별로 관리
	 * 
	 */
	// 2.1.4.1. 우편함에 택배 여부 확인
	private void post_Check(String resident_id) {
		System.out.println("우편함  구현 안됨 ");
	}

	/**
	 * @author 박찬
	 * @since 2020.09.07
	 * @see 입주민 마이페이지 , 입주민정보 누구인지 출력 1.입주민정보 수정 2.입주민정보 삭제 3.차량 추가등록
	 */
	// 2.1.5
	private void myPage(String resident_id, String resident_pass) {
		while (true) {
			System.out.println("1.입주민정보 수정, 2.입주민정보 삭제, 3.차량 추가등록, 4.뒤로가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:

				// 입주민정보 수정
				citizenRevise();
				break;
			case 2:
				// 입주민정보 삭제
				citizenDelete(resident_id, resident_pass);
				break;
			case 3:
				// 추가 차량등록
				carAdd();
				break;
			case 4:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}

	}

	// 2.1.5.1 입주민 정보수정
	/**
	 * @author 박찬
	 * @since 2020.09.07
	 * @see 입주민 정보수정
	 */
	private void citizenRevise() {
		System.out.println("입주민 수정공간");

	}

	// 2.1.5.2 입주민 정보 삭제
	/**
	 * @author 박찬
	 * @return
	 * @since 2020.09.07
	 * @see 입주민 정보 삭제
	 */
	private void citizenDelete(String resident_id, String resident_pass) {
		Scanner sc = new Scanner(System.in);
		System.out.println("정보 확인을 위해 비밀번호를 입력해주세요");
		// System.out.println(resident_pass);

		Map<String, String> params = new HashMap<>();
		params.put("resident_id", resident_id);
		String resident_PW = sc.next();

		if (resident_PW.equals(resident_pass)) {
			System.out.println("확인되셨습니다. 탈퇴하시겠습니까?");
			System.out.println("1. 예, 2. 아니오");

			String input = sc.next();
			params.put("input", input);
			params.get(input);

			switch (input) {
			case "1":
				service.delete(params);
				start();
				break;
				

			case "2":
				System.out.println("취소하셨습니다.");
				break;

			default:
				System.out.println("잘못 입력하셨습니다.");
				break;
			}

		} else {
			System.out.println("비밀번호가 틀리셨습니다. 다시 입력해주세요.");

		}

	}

	// 2.1.5.3.입주민 차량 추가등록
	/**
	 * @author 박찬
	 * @since 2020.09.07
	 * @see 입주민 차량 추가등록
	 */
	private void carAdd() {
		System.out.println("입주민 차량 추가등록");

	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 방문객이 방문 시 정보 입력하는 메서드, 이름 방문위치 차량번호
	 * 
	 */
	// 3. 방문객
	private void visit_Log() {
		Scanner sc = new Scanner(System.in);
		System.out.println("이름을 입력하세요");
		String visitName = sc.next();
		System.out.println("방문 위치를 입력하세요 ex)2동 103호 => 2103)");
		String visitLocation = sc.next();
		System.out.println("차량 4자리 번호를 입력하세요(없을시 0000)");
		String carNum = sc.next();
		Map<String, String> params = new HashMap<>();
		params.put("visitName", visitName);
		params.put("visitLocation", visitLocation);
		params.put("carNum", carNum);
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 관리자가 로그인으로 하는 메서드
	 * 
	 */
	// 4. 관리자 로그인
	private void manager_Login() {
		System.out.println("로그인 구현 아직 안함 ");

		// 로그인 구현 후 관리자 모드
		manager();
	}

	/**
	 * 
	 * @author 전진원
	 * @since 2020.09.07
	 * @see 관리자 모드로 접속후 업무 선택 (민원처리)
	 * 
	 */
	// 4.1 관리자 모드
	private void manager() {
		while (true) {

			System.out.println("1.민원게시판, 2.뒤로가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 민원 게시판
				community();
				break;
			case 2:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}
	}
}
