package project;

import java.util.Map;

public interface IService {
	/**
	 * 로그인을 위한 메서드
	 * @param params mem_id 사람의 아이디, mem_pass 비밀번호
	 * @return id와 pw가 일치하는 한명의 아이디, 일치하지 사람이 없으면 null
	 * @author 준
	 * @since 2020.09.04
	 * @see 수정내역 아직 없음
	 */
	String logIn(Map<String, String> params);

	String cr_id(Map<String, String> params);

}
