package project;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ViewClass {
	
	private IService service = new IServiceImpl();
	private String login_id;
	public void startMethod() {
		System.out.println("어서오세요");
		System.out.println("고르세요");
		System.out.println("1. 회원가입");
		System.out.println("2. 로그인");
		System.out.println("3. 끝내기");
		
		
		//고르기
		Scanner sc = new Scanner(System.in);
		int input = sc.nextInt();
		
		//메서드 이동
		
		switch(input){
		case 1:
			//가입
			createMember();
			break;
		case 2:
			//로그인
			logIn();
			break;
		case 3:
			//종료
			break;
		default :
			System.out.println("잘못 입력하셨습니다.");
			break;
		}

	
	}

	private void logIn() {
		//id, pw
		Scanner sc = new Scanner(System.in);
		System.out.println("아이디를 입력해주세요");
		String id = sc.next();
		System.out.println("비밀번호를 입력해주세요");
		String pw = sc.next();
		
		Map<String , String> params = new HashMap<>();
		params.put("id", id);
		params.put("pw", pw);
		
		login_id = service.logIn(params);
		
		if(login_id == null){
			System.out.println("그런 사람 없음");
		} else{
			System.out.println(login_id + "회원님 어서오세요");
			showMemList();
		}
		
	}

	private void showMemList() {
		
	}

	private void createMember() {

		Scanner sc = new Scanner(System.in);
		System.out.println("아이디를 입력해주세요");
		String id = sc.next();
		System.out.println("비밀번호를 입력해주세요");
		String pw = sc.nextLine();
		System.out.println("비고 입력 ");
		String etc = sc.next();
		Map<String, String> params = new HashMap<>();
		params.put("id", id);
		params.put("pw", pw);
		params.put("etc", etc);
		String login_id = service.cr_id(params);

	}
	
	
}
