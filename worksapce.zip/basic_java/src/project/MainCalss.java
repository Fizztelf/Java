package project;

public class MainCalss {
	public static void main(String[] args) {
		
		ViewClass vc = new ViewClass();
		vc.startMethod();
		
		
		
		
		
	}
}
