package project;

import java.util.Map;

public class IServiceImpl implements IService {

	
	private IDao dao = new IDaoImpl();
	
	@Override
	public String logIn(Map<String, String> params) {
		String id = dao.logIn(params);
		return id;
	}

	@Override
	public String cr_id(Map<String, String> params) {
		return dao.cr_id(params);
	}

}
