package project;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

public class IDaoImpl implements IDao {

	@Override
	public String logIn(Map<String, String> params) {

		String mem_id = params.get("id");
		String mem_pass = params.get("pw");

		Connection conn = null; // 연결
		Statement stmt = null; // 질의
		ResultSet rs = null; // 결과를 받기 위해

		String logIn_ID = null;

		params.put("id", "pw");

		String jj = params.get("id");
		System.out.println(params);

		try {
			// 1. 드라이버 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2. 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "JUN";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);

			// 3. 질의
			stmt = conn.createStatement();
			
			String sql = " SELECT * "
					      + "FROM MEMBER2 "
					      ;
			
			
//			String sql = "SELECT ID " + "FROM   MEMBER2 "
//					+ "WHERE  ID = '" + id+ "' AND PW = '"
//					+ pw + "'";

			// 질의 및 결과 저장

			rs = stmt.executeQuery(sql);
			// stmt.executeUpdate(sql) 한개가 지워질수도 있고 다섯개가 업데이트 될 수 있음. 그래서 int형
			while (rs.next()) {
				logIn_ID = rs.getString("ID");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 실패!");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속 실패!");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환실패");
			}
		}
		return logIn_ID;
	}

	@Override
	public String cr_id(Map<String, String> params) {
		String mem_id = params.get("id");
		String mem_pass = params.get("pw");
		String mem_etc = params.get("etc");
		Connection conn = null;
		Statement stmt = null;

		String login_ID = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2. 접속
			String url = "jdbc:oracle:thin:@localhost:1521/xe";
			String id = "JUN";
			String pw = "java";
			conn = DriverManager.getConnection(url, id, pw);
			stmt = conn.createStatement();

			String sql = "INSERT INTO MEMBER(ID,PASS,ETC) "
					+ " VALUES('" + mem_id + "','" + mem_pass + "','" + mem_etc
					+ "')";

			stmt.executeUpdate(sql);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 실패");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속실패");
		} finally {

			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}
		}
		return login_ID;
	}
}
	
	
	
	
	
	
	
	
	
