package f_OOP2;

import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnnoInner2 {
	public static void main(String[] args) {
		
		Button b1 = new Button();
		
		b1.addActionListener(new ActionListener() {		//객체생성과 동시에 객체 생성을 만든다. 이름이 없으니까, 일회용! b1만 쓸 수 있다.
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("1번 버튼 눌림");
			}
		});
		
		
		
		
		
	}
}
