package j_jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC_01 {
	public static void main(String[] args) {
		Connection conn = null;	//연결
		Statement stmt = null;	//질의
		ResultSet rs = null;	//결과를 받기 위해
		
		try {
			//1. 드라이버 로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//2. 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "JUN";
			String pw = "java";
		
			conn = DriverManager.getConnection(url, id, pw);
			
			//3. 질의
			stmt = conn.createStatement();
			String mem_id = "a001";
			String sql ="SELECT * "
					  + "FROM   MEMBER "
					  + "WHERE  MEM_ID = '"+mem_id+"'";
			
			// 질의 및 결과 저장
			rs = stmt.executeQuery(sql);
			// stmt.executeUpdate(sql) 한개가 지워질수도 있고 다섯개가 업데이트 될 수 있음. 그래서 int형
			while(rs.next()){
				String mem_name = rs.getString("MEM_NAME");
				System.out.println(mem_name);
			}
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 실패!");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속 실패!");
	    } finally {
	    	
	    	try {
	    		if(rs != null){
					rs.close();				
				}
				if (stmt != null){
					stmt.close();
				}
				if(conn != null){
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("자원반납실패");
			}
	    	
	    	
	    }
	    	
		
		
		
		
		// 멤버 crud 가입, 탈퇴, 정보수정, 회원에대한정보 읽어오기 숙제!
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
