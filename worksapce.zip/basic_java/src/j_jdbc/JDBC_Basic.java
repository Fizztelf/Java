package j_jdbc;

public class JDBC_Basic {
	public static void main(String[] args) {
		
		/*
		1. JDBC
		  - Java DataBase Connectivity
		  - ojdbc6.jar 파일이 필요하다.
		  
		2. JDBC 활용
		  - JDBC 드라이버 로딩
		    : Class,forName("")
		  - JDBC 접속
		    : DriverManage.getConnection()
		  - 질의(SQL)
		    : Statement, PreparedStatement
		  - 질의 결과 반납
		    : ResultSet 
		  - 접속 종료(자원반납)
		    : close()
		    
		    
		    
		3. 
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		    
		*/
		
		
		
		
		
		
		
		
		
		
	}
}
