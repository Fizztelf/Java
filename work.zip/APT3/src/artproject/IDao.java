package artproject;

import java.util.HashMap;
import java.util.Map;

public interface IDao {

	String residentlog_In(Map<String, String> params);

	int createCitizen(ResidentVO mb);

	int carAdd(Map<String, String> params);

	int delete(Map<String, String> params);

	boolean idcheak(ResidentVO mb);

	int createManger(ManagerVO mg);

	String carLoc(CarVO car);

	int write(CommunityVO cv);

	int writeedit(CommunityVO cv);

	int writedelete(int input);

	int elect(ExpensesVO ev);

	int writerepl(CommunityVO cv);

	int exWater(ExpensesVO ev);

	int exGuard(ExpensesVO ev);

	String postCheck(Map<String, String> params);

	int CitizenRevise(Map<String, String> params);

	int writing2(HashMap<String, String> params2);

	String mypage(String resident_id);


	int writeEdit(HashMap<String, String> params2);

	boolean midcheck(ManagerVO mg);

	String managerLogin(Map<String, String> params);

	String residentList(ResidentVO mb);

	int residentDel(ResidentVO mb);

	int residentCorrect(ResidentVO mb);

	String writeList();

	int userType(ResidentVO mb);

	int userType(ManagerVO mg);

	String carnum(int addr_num);


}