package artproject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class IServiceImpl implements IService {

	private IDao dao = new IDaoimpl();

	@Override
	public String residentlog_In(Map<String, String> params) {

		return dao.residentlog_In(params);
		// 오라클 덤프
	}

	@Override
	public int createCitizen(ResidentVO mb) {

		return dao.createCitizen(mb);
	}


	@Override
	public int carAdd(Map<String, String> params) {
		return dao.carAdd(params);
	}

	@Override
	public int delete(Map<String, String> params) {

		return dao.delete(params);
	}

	@Override
	public boolean idcheak(ResidentVO mb) {

		return dao.idcheak(mb);
	}

	@Override
	public int createManger(ManagerVO mg) {
		return dao.createManger(mg);

	}

	@Override
	public String carnum(int addr_num) {
		
		return dao.carnum(addr_num);
	}

	@Override
	public String carLoc(CarVO car) {
		return dao.carLoc(car);
	}

	
	@Override
	public int elect(ExpensesVO ev) {
		return dao.elect(ev);
	}


	@Override
	public int writedelete(int input) {
		return dao.writedelete(input);
	}

	@Override
	public int writerepl(CommunityVO cv) {
		return dao.writerepl(cv);
	}

	@Override
	public int exWater(ExpensesVO ev) {
		return dao.exWater(ev);
	}

	@Override
	public int exGuard(ExpensesVO ev) {
		return dao.exGuard(ev);
	}

	@Override
	public String postCheck(Map<String, String> params) {
		// TODO Auto-generated method stub
		return dao.postCheck(params);
	}


	@Override
	public int citizenRevise(Map<String, String> params) {
		return dao.CitizenRevise(params);
	}

	@Override
	public int writing2(HashMap<String, String> params2) {
		return dao.writing2(params2);
	}

	@Override
	public String myPage(String resident_id) {
		return dao.mypage(resident_id);
	}

	@Override
	public int writeEdit(HashMap<String, String> params2) {
		return dao.writeEdit(params2);
		
	}
	@Override
	public boolean midcheck(ManagerVO mg) {
		return dao.midcheck(mg);
	}

	@Override
	public String managerLogin(Map<String, String> params) {
		
		return dao.managerLogin(params);
	}

	@Override
	public String residentList(ResidentVO mb) {
		// TODO Auto-generated method stub
		return dao.residentList(mb);
	}

	@Override
	public int residentDel(ResidentVO mb) {
		// TODO Auto-generated method stub
		return dao.residentDel(mb);
	}

	@Override
	public int residentCorrect(ResidentVO mb) {
		// TODO Auto-generated method stub
		return dao.residentCorrect(mb);
	}

	@Override
	public String writeList() {
		// TODO Auto-generated method stub
		return dao.writeList();
	}

	@Override
	public int userType(ResidentVO mb) {
		// TODO Auto-generated method stub
		return dao.userType(mb);
	}

	@Override
	public int userType(ManagerVO mg) {
		// TODO Auto-generated method stub
		return dao.userType(mg);
	}



	@Override
	public List myWrite(String iD2) {
		// TODO Auto-generated method stub
		return null;
	}
	

	




	

}
