package artproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class IDaoimpl implements IDao {
	//입주민 로그인
	@Override
	public String residentlog_In(Map<String, String> params) {

		String resident_id = params.get("resident_id");
		String resident_pass = params.get("resident_pass");
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		int as = 1;

		String logIn_ID = null;
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

			String sql = "SELECT RESIDENT_ID " + "FROM  RESIDENT "
					+ "WHERE RESIDENT_ID ='" + resident_id
					+ "'AND RESIDENT_PASS ='" + resident_pass
					+ "'AND RESIDENT_CODE ='" + as + "'";

			rs = st.executeQuery(sql);

			while (rs.next()) {
				logIn_ID = rs.getString("RESIDENT_ID");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return logIn_ID;
	}

	//입주민 회원가입
	@Override
	public int createCitizen(ResidentVO mb) {
		String resident_id = mb.getResident_id();
		String resident_pass = mb.getResident_pass();
		String resident_name = mb.getResident_name();
		int resident_addr = mb.getAddr_num();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		int updateCount = 0;
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

			String sql = " INSERT INTO RESIDENT (RESIDENT_ID,RESIDENT_PASS,RESIDENT_NAME,ADDR_NUM) "
					+ " VALUES ('"
					+ resident_id
					+ "','"
					+ resident_pass
					+ "','" + resident_name + "','" + resident_addr + "')";

			updateCount = st.executeUpdate(sql);
			if (updateCount == 1) {
				System.out.println("성공적으로 회원 가입완료 하였습니다.");

			} else {
				System.out.println("가입 실패하였습니다.");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return updateCount;

	}

	//입주민 정보수정
	@Override
	public int CitizenRevise(Map<String, String> params) {
		String resident_id = params.get("resident_id");
		String inputPW = params.get("inputPW");
		String inputName = params.get("inputName");
		String inputAddr = params.get("inputAddr");
		String input = params.get("input");

		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";
			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();
			String sql;

			/**
			 * @author 전진원
			 * @since 2020.09.07
			 * @see 입주민이 마이페이지에서 입주민정보 수정을 보내면 비밀번호 이름 동후수 중에 고르고 값을 수정해주는 쿼리문
			 */
			switch (input) {
			case "1":
				sql = "UPDATE RESIDENT " + " SET RESIDENT_PASS = '" + inputPW
						+ "'" + " WHERE RESIDENT_ID = '" + resident_id + "'";
				st.executeUpdate(sql);
				break;
			case "2":
				sql = "UPDATE RESIDENT " + " SET RESIDENT_NAME = '" + inputName
						+ "'" + " WHERE RESIDENT_ID = '" + resident_id + "'";

				st.executeUpdate(sql);
				break;
			case "3":
				sql = "UPDATE RESIDENT " + " SET ADDR_NUM = '" + inputAddr
						+ "'" + " WHERE RESIDENT_ID = '" + resident_id + "'";

				st.executeUpdate(sql);
				break;

			default:
				System.out.println("취소");
				break;
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}

		return 0;
	}
	
	//차량등록
	@Override
	public int carAdd(Map<String, String> params) {
		int updatecount = 0;

		String resident_id = params.get("resident_id");
		String inputAddr = params.get("inputAddr");
		String input = params.get("input");

		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";
			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();
			String sql = "";

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {

				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}

		return updatecount;
	}
    
	//입주민 정보 삭제
	@Override
	public int delete(Map<String, String> params) {
		String resident_id = params.get("resident_id");
		String inputPW = params.get("inputPW");
		String input = params.get("input");
		int updatecount = 0;

		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();
			String sql = "UPDATE RESIDENT " + " SET RESIDENT_CODE = '0'"
					+ " WHERE RESIDENT_ID = '" + resident_id + "'";
			st.executeUpdate(sql);
			if (updatecount != 1) {
				System.out.println("삭제가 완료 되었습니다.");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return updatecount;

	}
	
	//입주민 아이디 중복체크
	@Override
	public boolean idcheak(ResidentVO mb) {
		boolean result = false;

		String resident_id = mb.getResident_id();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String Sid = "APT2";
			String pw = "java";
			conn = DriverManager.getConnection(url, Sid, pw);
			st = conn.createStatement();
			String sql = "SELECT RESIDENT_ID FROM RESIDENT WHERE RESIDENT_ID ='"
					+ resident_id + "'";
			rs = st.executeQuery(sql);
			if (rs.next()) {
				result = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}

		return result;
	}

	//관리자 회원가입
	@Override
	public int createManger(ManagerVO mg) {
		String manager_id = mg.getManager_id();
		String manager_pass =mg.getManager_pass();
		String manager_name =mg.getMamnager_name();
		String manager_hp = mg.getManager_hp();
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		int updateCount =0 ;
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

	
			String sql =" INSERT INTO MANAGER (MANAGER_ID,MANAGER_PASS,MANAGER_NAME,MANAGER_HP) "
					 +" VALUES ('"+manager_id+"','"+manager_pass+"','"+manager_name+"','"+manager_hp+"')";
		
			updateCount = st.executeUpdate(sql);
			if(updateCount == 1){
				System.out.println("성공적으로 회원 가입완료 하였습니다.");
			
			} else{
				System.out.println("가입 실패하였습니다.");
			}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return updateCount;
	
	}


	@Override
	public String carLoc(CarVO car) {
		return null;
	}

	@Override
	public int write(CommunityVO cv) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int elect(ExpensesVO ev) {
		Map<String, String> params = new HashMap<>();
		
		
//		String resident_id = params.get();
		int expenses_electricity = ev.getExpenses_electricity();
		int addr_num = ev.getAddr_num();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		int elec = 0;
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

			String sql = "SELECT MIN(A.EXPENSES_ELECTRICITY) "
					+ "FROM EXPENSES A, RESIDENT B, ADDR C "
					+ "WHERE A.ADDR_NUM = '"+addr_num+"'"
					+ "AND B.ADDR_NUM = C.ADDR_NUM "
					+ "GROUP BY A.EXPENSES_ELECTRICITY";

			rs = st.executeQuery(sql);

			while (rs.next()) {
				elec = rs.getInt("EXPENSES_ELECTRICITY");
				System.out.println("이번달 전기세는 :"+elec);
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return elec;
	}

	@Override
	public int writeedit(CommunityVO cv) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int writedelete(int input) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int writerepl(CommunityVO cv) {
		
		String manager_id = cv.getManager_id();
		String writer_repl = cv.getWriter_repl();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		
		
		
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

			String sql = "INSERT INTO COMMUNITY (MANAGER_ID,WRITE_REPL, WRITER_DATE)"
					+ " VALUES ('"+manager_id+"' ,'"+writer_repl+"' + SYSDATE) ";
			
			st.executeUpdate(sql);
			

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return 0;
	}

	@Override
	public int exWater(ExpensesVO ev) {
		return 0;
	}

	@Override
	public int exGuard(ExpensesVO ev) {
		// TODO Auto-generated method stub
		return 0;
	}
	//회원정보 페이지
	@Override
	public String mypage(String resident_id){
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		String mypage = null;

		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String Sid = "APT2";
			String pw = "java";
			conn = DriverManager.getConnection(url, Sid, pw);
			st = conn.createStatement();
			String sql = "SELECT * FROM RESIDENT WHERE RESIDENT_ID ='"+resident_id+"'";
			rs = st.executeQuery(sql);
			
			while (rs.next()) {
				System.out.println("==========================================");
				System.out.println(rs.getString("RESIDENT_NAME")+"님의 정보 입니다.");
				System.out.println("아이디: "+ rs.getString("RESIDENT_ID"));
				System.out.println("비밀번호 : " + rs.getString("RESIDENT_PASS"));
				System.out.println("이름: " + rs.getString("RESIDENT_NAME"));
				System.out.println("동/호수: "+rs.getString("ADDR_NUM"));
				System.out.println("==========================================");
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		
		return mypage;
	}

	//글작성(1)
	@Override
	public int writing2(HashMap<String, String> params2) {
		String resident_id = params2.get("resident_id");
		String writerSuggestions = params2.get("writerSuggestions");
		
	

		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();
			String sql = "INSERT INTO COMMUNITY (WRITER_ID ,WRITER_SUGGESTIONS, WRITER_DATE) "
					+ " VALUES ('"+resident_id+"','"+ writerSuggestions+"',SYSDATE) ";
			st.executeUpdate(sql);

			//SELECT COUNT(컬럼명) FROM 테이블명;
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return 0;
	
	}

	//우편물 확인
	@Override
	public String postCheck(Map<String, String> params) {
		String resident_id = params.get("resident_id");

		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

			String sql = "SELECT A.POST_NAME " + " FROM POST A, RESIDENT B "
					+ " WHERE A.ADDR_NUM = B.ADDR_NUM "
					+ " AND B.RESIDENT_ID = '" + resident_id + "'";
			rs = st.executeQuery(sql);

			while (rs.next()) {
				String a = rs.getString("POST_NAME");
				if (a == null) {
					System.out
							.println("──────────────────────────────────────");
					System.out.println("\t배송온 택배가 없습니다.");
					System.out
							.println("───────────────────────────────────────");
				} else {
					System.out.println(a + " 상품이 택배함에 배송왔습니다");
				}
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return null;
	}

	//글 수정(1)
	@Override
	public int writeEdit(HashMap<String, String> params2) {
		String resident_id = params2.get("resident_id");
		String writerSuggestions = params2.get("writerSuggestions");
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();
			String sql = "UPDATE  COMMUNITY "
					+ " SET WRITER_SUGGESTIONS = '"+writerSuggestions+"'"
					+ " WHERE WRITER_ID = '"+resident_id+"'";
			st.executeUpdate(sql);
			System.out.println("수정이 완료되었습니다.");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return 0;
	}

	//관리자아이디 중복 체크
	@Override
	public boolean midcheck(ManagerVO mg) {
		boolean result = false;

		String manager_id = mg.getManager_id();
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;

		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String Sid = "APT2";
			String pw = "java";
			conn = DriverManager.getConnection(url, Sid, pw);
			st = conn.createStatement();
			String sql = "SELECT MANAGER_ID FROM MANAGER WHERE MANAGER_ID ='"+manager_id+"'";
			rs = st.executeQuery(sql);
			if(rs.next()){
				result = true;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		
		return result;
	}

	//관리자 로그인
	@Override
	public String managerLogin(Map<String, String> params) {
		String manager_id = params.get("manager_id");
		String manager_pass = params.get("manager_pass");
		
		
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		

		String managerlogin = null;
		
		try {
			// 1.드라이버로딩
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// 2 접속
			String url = "jdbc:oracle:thin:@localhost:1521/XE";
			String id = "APT2";
			String pw = "java";

			conn = DriverManager.getConnection(url, id, pw);
			// 3.질의 및 결과실행
			st = conn.createStatement();

			String sql = "SELECT MANAGER_ID " + "FROM  MANAGER " + "WHERE MANAGER_ID ='"
					+ manager_id + "'AND MANAGER_PASS ='" + manager_pass +"'";
	
	
//			String sql = "SELECT A.RESIDENT_ID, B.MANAGER_ID "
//					+ "FROM  RESIDENT A, MANAGER B "
//					+ " WHERE A.RESIDENT_ID =" +"'"+resident_id+"'"
//					+"AND B.MANAGER_ID = " +"'"+manager_id+"'"; 
		
			
			rs = st.executeQuery(sql);
		
			while (rs.next()) {
				managerlogin = rs.getString("MANAGER_ID");
			
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("드라이버 로딩 하지 못하였습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("접속을 실패하였습니다.");
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (st != null) {
					st.close();
				}
				if (conn != null) {
					conn.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("반환 실패");
			}

		}
		return managerlogin;
	}

	@Override
	public String residentList(ResidentVO mb) {
		return null;
	}

	@Override
	public int residentDel(ResidentVO mb) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int residentCorrect(ResidentVO mb) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String writeList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int userType(ResidentVO mb) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int userType(ManagerVO mg) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String carnum(int addr_num) {
		// TODO Auto-generated method stub
		return null;
	}
}

	


