package artproject;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ViewClass {
	private IService service = new IServiceImpl();
	private String login_id;
	private int createCitizen;
	private String managerlogin;
	private int addr_num;
	private int createManger;
	private int elec;

	ResidentVO mb = new ResidentVO();
	ManagerVO mg = new ManagerVO();
	AddrVO av = new AddrVO();
	CarVO car = new CarVO();
	CommunityVO cv = new CommunityVO();
	ExpensesVO ev = new ExpensesVO();
	PostVO pv = new PostVO();

	// 시작시

	void start() {
		while (true) {
			System.out.println("1.회원가입  2.입주민 로그인  3.방문객 4.관리자 로그인  5.종료");
			Scanner sc = new Scanner(System.in);
			try {

				int num = sc.nextInt();
				switch (num) {
				case 1:
					// 회원 가입
					// create_id();
					create_id();
					break;
				case 2:
					// 입주민 로그인
					residentlog_In();
					break;
				case 3:
					// 방문객
					visit_Log();
					break;
				case 4:
					// 관리자로그인
					manager_Login();
					break;

				case 5:
					// 종료
					System.out.println("프로그램이 종료됩니다.");
					System.exit(0);// 종료
				default:
					System.out.println("잘못 입력했습니다.");
					System.out.println("프로그램이 종료됩니다.");
					System.exit(0);// 종료
					break;
				}

			} catch (InputMismatchException e) {

				System.out.println("형식에 맞지않아서 강제 종류합니다.");
				break;
			}
		}
	}

	// 1. 회원가입
	private void create_id() {
		while (true) {
			System.out.println("1.입주민, 2.관리자, 3.뒤로가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 입주민 회원가입
				create_Citizen();
				break;
			case 2:
				// 관리자 회원가입
				create_Manager();
				break;
			case 3:
				return;
				// 뒤로가기
			default:
				System.out.println("잘못 입력하였습니다.");
				break;
			}
		}
	}

	// 1.1 입주민 회원가입
	private void create_Citizen() {
		boolean in = false;

		// 아이디 입력
		// 비밀빈호 입력
		// 이름 입력
		// 동/호수 입력
		do {
			String residentID = inputID();// 아이디 입력 메소드
			mb.setResident_id(residentID);
			in = idcheak();
		} while (in == true);

		String residentPW = inputPW();// 비밀번호 입력 메소드
		mb.setResident_pass(residentPW);

		String residentNAME = inputNAME();// 이름 입력 메소드
		mb.setResident_name(residentNAME);

		int residentADDR = inputADDR();// 주소 입력 메소드
		mb.setAddr_num(residentADDR);

		createCitizen = service.createCitizen(mb);
		start();

	}

	private int inputADDR() {
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("동입력해주세요. ex)2동 102호 => 2102");
			System.out.println("1동 2동,1층에서 9층까지 각동의 각층은 2집씩 존재한다.");
			int addr = sc.nextInt();
			Pattern p = Pattern.compile("^[1-2][1-9][0][1-2]$");
			Matcher m = p.matcher(Integer.toString(addr));
			if (m.matches()) {
				return addr;
			}
			System.out.println("동호수 입력 잘해라고 ^<^");
		}

	}

	private String inputNAME() {
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("이름을 입력해주세요");
			System.out.println("2글자에서 5글자만 가능 ");
			String name = sc.next();
			Pattern p = Pattern.compile("^[가-힣]{2,5}$");
			Matcher m = p.matcher(name);
			if (m.matches()) {
				return name;
			}
			System.out.println("형식에 위배되는 이름입니다. ^_^ㅗ   ");

		}
	}

	private String inputPW() {
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("비밀번호를 입력해주세요");
			System.out.println("8자 이상 20자 이하 숫자와 문자를 입력하세요.");
			String pw = sc.nextLine();

			Pattern p = Pattern.compile("^[A-Za-z0-9]{8,20}$");
			Matcher m = p.matcher(pw);
			if (m.matches()) {
				return pw;
			}
			System.out.println("글자수 맞춰서 숫자와 문자 입력하라했잖아 ㅡㅡ;");
		}
	}

	private String inputID() {
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("아이디를 입력해주세요");
			System.out.println("3글자에서 10글자 문자와 숫자 ");
			String id = sc.nextLine();
			Pattern p = Pattern.compile("[a-zA-z][a-zA-Z0-9]{3,10}");
			Matcher m = p.matcher(id);
			if (m.matches()) {
				return id;
			}
			System.out.println("아이디가 잘못된 형식입니다.");
		}
	}

	private boolean idcheak(){
		while (true) {
			boolean idcheak = service.idcheak(mb);
			boolean midcheck = service.midcheck(mg);
			if (idcheak== true || midcheck == true) {
				System.out.println("중복된 아이디 입니다.");
				return true;
			} else {
				System.out.println("사용가능한 아이디입니다.");
				return false;
			}
		
		}
	}

	// 1.2 관리자 회원가입
	// 1.2 관리자 회원가입
	private void create_Manager() {

		boolean in = false;

		// 아이디를 입력받는다.
		do {
			String managerID = inputID();
			mg.setManager_id(managerID);
			String residentID = inputID();
			mb.setResident_id(residentID);
			in = idcheak();
			while(true){
				if(residentID == managerID){
					System.out.println("중복입니다.");
					start();
				} else {
					System.out.println();
				}
				break;
			}
				
			// 비밀번호 입력받는다.
		} while (in == true);
		String managerPW = inputPW();
		mg.setManager_pass(managerPW);
		// 이름을 입력 받는다.
		String managerNAME = inputNAME();
		mg.setMamnager_name(managerNAME);
		// 전화번호 입력 받는다.
		String managerHP = managerHP();
		mg.setManager_hp(managerHP);
		// sql
		// int createManager(관리자VO vo);
		createManger = service.createManger(mg);
		start();

	}

	private String managerHP() {
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("형식에 맞는 전화번호를 입력해주세요");
			System.out.println("형식 : 01x-xxxx-xxxx");
			String HP = sc.nextLine();
			Pattern p = Pattern.compile("^01[0-17-9](-)[0-9]{4}(-)[0-9]{4}$");
			Matcher m = p.matcher(HP);
			if (m.matches()) {
				return HP;
			}
			System.out.println("형식에 위배하는 번호입니다. 혹시 - 는 입력하셨나요?? (^>^;;)");
		}
	}

	private String inputManagerId() {
		// id 중복체크
		// sql
		// int createManager(관리자VO vo);
		// 정규식

		return null;
	}

	// 2. 입주민 로그인
	private void residentlog_In() {
		// ID 입력
		// PW 입력
		// inputID();
		// inputPW();
		String resident_id = inputID();
		String resident_pw = inputPW();
		Map<String, String> parms = new HashMap<>();
		parms.put("resident_id", resident_id);
		parms.put("resident_pass", resident_pw);

		login_id = service.residentlog_In(parms);

		// 로그아웃 null넣어야한다.
		if (login_id == null) {
			System.out.println("회원정보가 없습니다.");

		} else {
			System.out.println(resident_id + "회원님 어서오세요");
			citizen(resident_id, resident_pw, addr_num);
		}

		// 로그인 구현 후 입주민 모드

	}

	// 2.1. 입주민 모드
	private void citizen(String resident_id, String resident_pw,int addr_num) {

		while (true) {
			System.out
					.println("1.차량조회, 2.게시판 , 3.관리비 확인, 4.우편물 확인  5.마이페이지 6.뒤로 가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 1.차량 조회
				car_Look(addr_num);
				break;
			case 2:
				// 2.게시판
				community(resident_id);
				break;
			case 3:
				// 3.관리비 확인
				expenses();
				break;
			case 4:
				// 4.우편물 확인
				delivery(resident_id);
				break;
			case 5:
				// 마이페이지
				myPage(resident_id, resident_pw);
				break;
			case 6:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 입력 했습니다.");
				break;
			}
		}
	}

	// 2.1.1. 차량 조회
	private void car_Look(int addr_num) {
		while (true) {
			System.out.println("1.차량 번호 확인, 2.주차위치확인, 3.뒤로가기 ");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 차량번호 와 입주자의 정보 출력
				car_Num(addr_num);
				break;
			case 2:
				// 주차 위치 확인
				car_Loc();
				break;
			case 3:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}
	}

	// 2.1.1.1.차량 번호 확인
	private void car_Num(int addr_num) {
		// 아이디를 받아와서 동호수를 확인하고 해당하는 차량번호, 차량종 확인
		av.getAddr_carnum();
		service.carnum(addr_num);
		System.out.println("차량 확인 구현 안됨 ");

	}

	// 2.1.1.2.주차 위치 확인
	private void car_Loc() {
		// 아이디를 받아와서 동호수를 매칭하여 지정된 주차공간 번호 확인
		car.getCar_num();
		service.carLoc(car);
		System.out.println("주차확인 구현 안됨 ");

	}


	private int userType(){
		int code = 1;
	mb.getResident_code();//입주민 코드
	mg.getManager_code();
	service.userType(mb);
	 service.userType(mg);
	 
	 return code;
	}
	// 2.1.2. 소통게시판
	private void community(String ID2) {
		while (true) {
			int id =userType();
			// id는 임시로 해둔거 회원 관리자 구별 구현해야된다.
			
			// 회원일때
			if (id == 1) {
				System.out.println("1.민원글작성, 2.민원글수정, 3.민원글삭제,4.민원글조회 5.뒤로가기");
				Scanner sc = new Scanner(System.in);
				int input = sc.nextInt();
				switch (input) {
				case 1:
					// 민원글 작성
					writing(ID2);
					break;
				case 2:
					// 민원글 수정
					edit(ID2);
					break;
				case 3:
					// 민원글 삭제
					delete(ID2);
					break;
					
				case 4:
					// 민원글 조회
					writeList();
					break;
				
				case 5:
					// 뒤로가기
					return;
				default:
					System.out.println("잘못 눌렀습니다.");
					break;
				}
			}
			// 관리자
			
			else if (id == 2) {
				System.out.println("1. 댓글 작성, 2.민원글삭제, 3.민원글 조회 3.뒤로가기");
				Scanner sc = new Scanner(System.in);
				int input = sc.nextInt();
				switch (input) {
				case 1:
					// 민원글 댓글 작성
					comment(ID2);
					break;
				case 2:
					// 민원글 삭제
					delete(ID2);
					break;
				case 3:
					writeList();
					break;
				case 4:
					// 뒤로가기
					return;
				default:
					System.out.println("잘못 눌렀습니다.");
					break;
				}
			}

		}
	}

	private void writeList() {
		// TODO Auto-generated method stub
		service.writeList();
		
	}

	// 2.1.2.1.민원글 작성(거주민)
	private void writing(String resident_id) {
		String writerSuggestions = writeSC();
		HashMap<String, String> params2 = new HashMap<>();
		params2.put("resident_id", resident_id);
		params2.put("writerSuggestions", writerSuggestions);

		service.writing2(params2);
	}

	// 2.1.2.2.민원글 수정(거주민)
	private void edit(String resident_id) {
		HashMap<String, String> params2 = new HashMap<>();
		String writerSuggestions = writeSC();
		params2.put("resident_id", resident_id);
		params2.put("writerSuggestions", writerSuggestions);
		service.writeEdit(params2);

	}

	// 게시판에 글쓸떄 사용하는 메서드
	private String writeSC() {
		Scanner sc = new Scanner(System.in);
		System.out.println("민원 내용을 작성하세요.");
		String a = sc.nextLine();
		return a;
	}

	// 2.1.2.3.민원글 삭제
	   private void delete(String iD2) {
	      while(true){
	         
	         cv.getWriter_suggestions();
	         Scanner sc = new Scanner(System.in);
	         int input = sc.nextInt();
	         System.out.println("1.본인 작성글 확인 2.뒤로가기");
	         switch (input) {
	         case 1:
	            System.out.println("본인 작성글 확인 ");
	            myWrite(iD2);
	            break;
	         case 2:
	            return;
	         default:
	            System.out.println("잘 못 입력 되었습니다. ");
	            break;
	         }
	      }
	   }
	   //글 확인  후 글 삭제 
	   private void myWrite(String iD2) {
	      service.myWrite(iD2);
	      //글번호를 뛰어줘야하는거 구현해야됨 
	      //글확인 했으면 글번호 선택해서  그거에 맞는거 지워야함 
	      
	      int write_num =0;
	      Scanner sc = new Scanner(System.in);
	      System.out.println("본인 글중에 삭제 할 글번호를 입력하세요");
	      int input = sc.nextInt();
	      if(input == write_num){
	         service.writedelete(input);
	      }
	   
	   }

	// 2.1.2.4.민원글 댓글 작성(관리자)
	private void comment(String ID2) {
		cv.getWriter_repl();
		service.writerepl(cv);
		System.out.println("민원글댓글  구현 안됨 ");

	}

	// 2.1.3. 관리비 확인
	private void expenses() {
		while (true) {

			System.out.println("1.전기세, 2.수도세, 3.경비비, 4.뒤로가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 전기세 확인
				electrivity();
				break;
			case 2:
				// 수도세 확인
				water();
				break;
			case 3:
				// 경비비 확인
				guard();
				break;
			case 4:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}
	}

	// 2.1.3.1. 전기세
	private void electrivity() {
		ev.getExpenses_electricity();
		service.elect(ev);
//		ev.setExpenses_electricity(expenses_electricity);
	
	}

	// 2.1.3.2. 수도세
	private void water() {
		ev.getExpenses_water();
		service.exWater(ev);
		System.out.println("수도세  구현 안됨 ");
	}

	// 2.1.3.3. 경비비
	private void guard() {
		ev.getExpenses_guard();
		service.exGuard(ev);
		System.out.println("경비비  구현 안됨 ");
	}

	// 2.1.4. 우편물 확인
	private void delivery(String resident_id) {
		while (true) {
			System.out.println("1.우편물 확인, 2.뒤로가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 우편함에 택배 여부 확인
				post_Check(resident_id);
				break;
			case 2:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}
	}

	// 2.1.4.1. 우편함에 택배 여부 확인
	private void post_Check(String resident_id) {
		Map<String, String> params = new HashMap<>();
		params.put("resident_id", resident_id);
		service.postCheck(params);
	}

	private void page(String resident_id) {
		service.myPage(resident_id);

	}

	// 2.1.5 마이페이지
	private void myPage(String resident_id, String resident_pass) {

		while (true) {
			page(resident_id);

			System.out.println("1.입주민정보 수정, 2.입주민정보 삭제, 3.차량 추가등록, 4.뒤로가기");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:

				// 입주민정보 수정
				citizenRevise(resident_id);
				break;
			case 2:
				// 입주민정보 삭제
				citizenDelete(resident_id, resident_pass);
				break;
			case 3:
				// 추가 차량등록
				carAdd(resident_id);
				break;
			case 4:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}

	}

	// 2.1.5.1 입주민 정보수정

	private void citizenRevise(String resident_id) {

		System.out.println("1. 비밀번호수정, 2.이름 수정, 3.동호수변경, 4.취소");
		Scanner sc = new Scanner(System.in);
		Map<String, String> params = new HashMap<>();

		params.put("resident_id", resident_id);
		String input = sc.next();
		params.put("input", input);
		switch (input) {
		case "1":
			String changePW = inputPW();
			params.put("inputPW", changePW);
			break;
		case "2":
			String changeNAME = inputNAME();
			params.put("inputName", changeNAME);
			break;
		case "3":
			int changeADDR = inputADDR();
			params.put("inputAddr", Integer.toString(changeADDR));
			break;
		case "4":

			break;
		default:
			break;
		}
		service.citizenRevise(params);

	}

	// 2.1.5.2 입주민 정보 삭제

	private void citizenDelete(String resident_id, String resident_pw) {
		Scanner sc = new Scanner(System.in);
		Map<String, String> params = new HashMap<>();
		String deletePW = inputPW();
		params.put("resident_id", resident_id);
		
		if (deletePW.equals(resident_pw)) {
			System.out.println("확인되셨습니다. 탈퇴하시겠습니까?");
			System.out.println("1. 예, 2. 아니오");

			String input = sc.next();
			
			switch (input) {
			case "1":
				service.delete(params);
				start();
				break;

			case "2":
				System.out.println("취소하셨습니다.");
				break;

			default:
				System.out.println("잘못 입력하셨습니다.");
				break;
			}

		} else {
			System.out.println("비밀번호가 틀리셨습니다. 다시 입력해주세요.");

		}

	}

	// 2.1.5.3.입주민 차량 추가등록

	private void carAdd(String resident_id ) {
		System.out.println("입주민 차량 추가등록");
		Scanner sc = new Scanner(System.in);
		int carnum = inputCarNum();
		String carType = inputCarType();
		Map<String, String> params = new HashMap<>();
		Map<String, Integer> params2 = new HashMap<>();
		params2.put("carnum", carnum);
		params.put("carType", carType);
		// params.put("addr", addr);
//		params.put("carOwner", residen_name);
		service.carAdd(params);

	}

	// 차 종류 입력
	private String inputCarType() {
		Scanner sc = new Scanner(System.in);

		System.out.println("차량명을 입력해주세요 ex)펠리세이드 ");
		String carType = sc.nextLine();
		return carType;
	}

	// 차 번호 입력
	private int inputCarNum() {
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("차량 번호 숫자 4자리를 입력해주세요");
			System.out.println("없을시 0000");
			int carNum = sc.nextInt();

			Pattern p = Pattern.compile("[0-9]{4}");
			Matcher m = p.matcher(Integer.toString(carNum));
			if (m.matches()) {
				return carNum;
			}
			System.out.println("차번호를 다시 입력하세요");
		}
	}

	// 3. 방문객
	private void visit_Log() {
		String visitNAME = inputNAME();
		int visitADDR = inputADDR();
		int carNum = inputCarNum();
		Map<String, String> params = new HashMap<>();
		Map<String, Integer> params1 = new HashMap<>();
		params.put("visitName", visitNAME);
		params1.put("visitLocation", visitADDR);
		params1.put("carNum", carNum);
	}

	// 4. 관리자 로그인
	private void manager_Login() {
		String manager_id = inputID();
		String manager_pass = inputPW();
		Map<String, String> params = new HashMap<>();
		params.put("manager_id", manager_id);
		params.put("manager_pass", manager_pass);

		managerlogin = service.managerLogin(params);

		if (managerlogin == null) {
			System.out.println("정보가 없습니다");

		} else {
			System.out.println("관리자님, 어서오세요");
			manager(manager_id, manager_pass);
		}
		// 로그인 구현 후 관리자 모드

	}

	// 4.1 관리자 모드
	private void manager(String managerID, String manager_pass) {
		while (true) {

			System.out.println("1.민원게시판, 2. 입주민 회원정보  3.입주민 회원 삭제 4. 삭제된 회원 수정 5.뒤로가기 ");
			Scanner sc = new Scanner(System.in);
			int input = sc.nextInt();
			switch (input) {
			case 1:
				// 민원 게시판
				community(managerID);
				break;
			case 2:
				// 입주민 회원 정보
				residentList();
				break;
			case 3:
				// 입주민 회원 삭제
				residentDel();
				break;
			case 4:
				// 삭제된 회원 수정
				residentCorrect();
				break;
			case 5:
				// 뒤로가기
				return;
			default:
				System.out.println("잘못 눌렀습니다.");
				break;
			}
		}
	}
	//삭제된 회원 수정
	private void residentCorrect() {
		service.residentCorrect(mb);
	}
	//입주민 삭제 
	private void residentDel() {
		service.residentDel(mb);
	}
	
	//입주민 회원 정보 
	private void residentList() {
		service.residentList(mb);
		
	}
}
