package h_javaLang;

import java.io.Serializable;

public class EqualsTest02 {
	public static void main(String[] args) {
		
		Person pr1 = new Person(960713L);
		Person pr2 = new Person(960713L);
		
		System.out.println(pr1 == pr2);
		System.out.println(pr1.equals(pr2));
		
//		String a = null;
//		System.out.println(a.equals("")); // 이렇게 하면 터짐 ..
	
	
		System.out.println(pr1.toString());
		System.out.println(pr1.hashCode());
	}
}

class Person implements Serializable{

	
	long regNo;
	
	Person(long regNo){
		this.regNo = regNo;
	}

	@Override
	public boolean equals(Object obj) {
		boolean result = false;
		if(obj instanceof Person && obj != null){
			result = this.regNo == ((Person)obj).regNo;			//pr1 == pr2
		}
		return result;
	}

	@Override		//alt + shit + s => s => enter
	public String toString() {
		return "Person [regNo=" + regNo + "]";
	}
}


 
