package h_javaLang;

public class StringTest01 {
	public static void main(String[] args) {
		
		String str1 = "abc";	//abc는 리터럴
		String str2 = "abc";
		
		System.out.println(str1 == str2);		//주소를 비교
		System.out.println(str1.equals(str2));
		
		String str3 = new String("abc");		//인자값
		String str4 = new String("abc");
		
		
		System.out.println(str3 == str4);
		System.out.println(str3.equals(str4));	//예측할 수 있는것은 equals 메서드가 오버라이드 되어 있다.
		
		
		
		
		
		
		
		
		
	}
}
