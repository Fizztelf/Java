package h_javaLang;

public class EqualsTest01 {
	public static void main(String[] args) {
		
		
		Value v1 = new Value(10);
		Value v2 = new Value(10);
		
		System.out.println(v1 == v2);		//false
		System.out.println(v1.equals(v2));	//false , 주소값을 비교 
	}
}



class Value{
	
	int value;
	Value(int Value){
		this.value = Value;
	}
}