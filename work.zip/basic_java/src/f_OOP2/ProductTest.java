package f_OOP2;

import java.util.Vector;

public class ProductTest {
   public static void main(String[] args) {
      
      //맥북 300
      NoteBook nb = new NoteBook("맥북", 300);
      
      //스타일러 200
      Styler st = new Styler("LG", 200);
      
      //냉장고는 500
      Fridge f = new Fridge("SAMSUNG", 500);
      
      //고객 입장
      Buyer b = new Buyer("준", 1000);
      
      
      
      //쇼핑
      b.buy(f);
      b.buy(nb);
      b.buy(nb);
      b.buy(st);
      
      b.summary();
      b.refund(nb);
      
      
      
   }

   
}


class Product{
   //제품이름
   String name;
   //가격
   int price;
   //보너스 포인트(마일리지)
   int bonusPoint;
   
   public Product(String name, int price){
      this.name = name;
      this.price = price;
      bonusPoint = price/10;
   }
}

//class NoteBook extends Product{      기본생성자 타입
//   
//}

class NoteBook extends Product {
   NoteBook(String name, int price) {
      super(name, price);
   }

   @Override
   public String toString() {      // alt + shif + s  ==> s ==> enter
      return "NoteBook";
   }
}

class Styler extends Product{
   public Styler(String name , int price){
      super(name, price);
      
      
  }

   @Override
   public String toString() {
      return "Styler";
   }
}


class Fridge extends Product{
   public Fridge(String name, int price) {
      super(name, price);
      
      
   }

   @Override
   public String toString() {
      return "냉장고";
   }
}

class Buyer {
   String name;
   int money;
   int mileage;
   
   Vector item = new Vector();
   
   public Buyer(String name, int money) {
      this.name = name;
      this.money = money;
   }
   
   void buy(Product nb){
      if(money < nb.price){
         System.out.println("돈가져와");
         return;
      }
      money -= nb.price;
      mileage += nb.bonusPoint;
      item.add(nb);
      
      
      
      System.out.println(name+"고객님 "+nb+"를 구매해 주셔서 감사합니다");
      
   }
   
  


   //1. summary               item에서 꺼내왕.. 제품들
   /*
            영 수 증
      구매목록
         NoteBook      300만원
         Styler      200만원
           총합         500만원
      xxx 고객님의 남은 돈은 xxx만원이고 마일리지는 xxx입니다
      오늘도 좋은 하루 보내십시오. 고갱님
   */
   void summary(){
	   System.out.println("\t영\t수\t증");
	   System.out.println("\t구매목록");
	   if(item.size() == 0){
		   System.out.println("구매하신 물건이 없습니다");
		   return;
	   }
	   int sum = 0;
	   //물품들은 아이템에 저장되어있음. 아이템에 있는 것을 하나 씩 꺼내오려면 for문을 써야함
	   for(int items = 0; items < item.size(); items++){
		   if(item.get(items) instanceof Product){
			   Product p1 = (Product)item.get(items);
			   System.out.println("\t"+p1.name+"\t"+p1.price+"만원");
			   sum += p1.price;
		   }
	   }
	   System.out.println("\t합계\t"+sum+"만원");
	   System.out.println(name+" 님의 남는 돈은"+money+" 만원이고 마일리지는 "+mileage+" 입니다");
   }
   

   //2. refund
   /*
   1. 고려사항
     - 물건을 산 내역이 없을 때
     - 내가 산 물건만 반품
   */
  
   
   	void refund(Product p){
   		if(item.isEmpty()){
   			System.out.println("구매하신 물건이 없습니다.");
   			return;
   		}
   		if(item.remove(p)){
   			money += p.price;
			mileage -= p.bonusPoint;
			System.out.println(p+"를 반품하셨습니다");
   		} else {
   			System.out.println(p+"반품할 물건이 없습니다.");
   		}
   	}  
}



//3. 물품의 수량을 관리

//4. 고객들의 목록을 관리해주세요































