package f_OOP2;

import z_exam.ProTest_03;

public class ProTest_01 extends ProTest_03{
	public static void main(String[] args) {
		
		ProTest_02 pt2 = new ProTest_02();
		ProTest_03 pt3 = new ProTest_03();
		ProTest_01 pt1 = new ProTest_01();
		
		// 시간 0~23, 분 0~59 , 초 0~59
		
		
		
	}

}
