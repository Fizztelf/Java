package i_collection;

public class Collection_01 {
	public static void main(String[] args) {
		
		/*
		1. Collection Framework
		  - Collection
		    : 데이터 그룹
		  - Framework
		    : 일을 하기 위한 틀
		    : 표준화가 가능하다.
		    
		    Collections        - Collection - list(순서o, 데이터 중복o) - Vector<> (동기)
		    														- Stack
		    														- Arraylist(비동기,벡터보다 더 빠름)
		    														
											= set (순서x, 데이터 중복x) - Hashset (이안에는 Hashmap으로 만들어져있다)
																	- Treeset (테이터 검색을 위한)
		
		
							   - Map <키,값>					- Hashmap
							    (기본적으로 순서가 없음,
							           키는 중복허용하지 않음,
							                         값은 중복허용) 
				
		2. 핵심 interface
		  - List
		    : 순서가 있다.
		    : 데이터의 중복을 허용한다
		    : List를 구현한 구현체  - Arraylist, Vector, Stack, LinkedList
		    : List의 실제 사용 예(대기표 명단)
		    
		  - Set
		    : 순서가 없다.
		    : 데이터의 중복을 허용하지 않는다.
		    : 구현제에는 HashSet, TreeSet
		    : Set의 실제 사용 예(정수의 집합)
		    
		  - Map <key, value>
		    : 키와 값으로 이루어져 있다.
		    : 기본적으로 순서가 없다.
		    : 키는 중복 허용하지 않고, 값을 중복 허용한다
			: 현재는 쓰지 않는 HashTable, 현재에 쓰는 HashMap 순서가 없으니까 중복허용하지 않음 , TreeMap (검색)
			: Map의 실제 사용 예(우편번호, 지역번호)
		
		
		3. ArrayList
		  - 배열을 사용하였을 때 길이를 한번 정하면 변경이 불가한 단점을 보안하기 위해 만들어졌다.
		  - 메서드들
		    : add()     				  -> 객체를 추가한다
		    : remove()  				  -> 객체를 제거한다
			: get(int index)			  -> index번째 객체를 얻어온다
			: set(int index, Object obj)  -> index번째의 객체를 교체한다
		
		
		4. LinkedList
		  - 자신의 데이터와 다음 데이터의 주소를 가지고 있다.
		  - 이전 요소를 찾을 수 없다.
		  
		  
		5. DoubleLinkedList
		  - 자신의 데이터와 이전 데이터의 주소, 다음 데이터의 주소를 가지고 있다.
		  
		  
		6. Stack
		  - First In Last Out : FILO
		  - push() : 객체추가 
		  - pop() : 추출
		  - search() : 원하는 객체를 찾는다
		  - peak() : 가장 위의 객체를 가져온다		
		
		
		7. Queue
		  - First In First Out : FIFO
		  - offer() : 추가
		  - poll() : 추출
		
		  
		8. HashSet
		  - 새로운 요소를 추가하기 위해 add, addAll메서드를 사용할 때 중복추가 될 때는 실패하게 된다

		
		8. Map<Object, Object>   - HashMap
		  - 키(key)와 값(value)로 이루어져 있다.
		  - 순서가 없기 때문에 중복을 비허용하고 값은 중복을 허용한다.
	      - 키와 값이 type으로 Object 형태이지만 일반적으로는 키의 경우는 String으로 많이 사용한다.
	      - method들
	        put() : 객체를 추가
		    get(key) : 원하는 객체의 값을 가져온다.
		    remove(key) : 지우기  
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		*/
		
		
		
		
		
		
	}
}
