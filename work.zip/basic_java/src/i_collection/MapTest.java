package i_collection;

import java.util.HashMap;
import java.util.Map;

public class MapTest {
	public static void main(String[] args) {
		
		Map<String, Integer> param = new HashMap<>();	// Object, Object
		
		param.put("김성준", 50);  //auto-boxing
		param.put("박찬", 60);
		param.put("전진원", 15);
		param.put("김선준", 20);
		// put()  :  insert 겸 update
		
		//R
		int jun = param.get("김선준");		//반환값 integer
		System.out.println(jun);
		System.out.println(param);
		//D
		System.out.println(param.remove("전진원"));
		System.out.println(param);
		
		
		Map<String, String> mem = new HashMap<>();
				
		mem.put("mem_id", "a001");
		mem.put("mem_pw", "asdfasdf");
		
//		SELECT *
//		FROM 	MEMBER
//		WHERE MEM_ID = mem.get("mem_id")
//		  AND MEM_PW = mem.get("mem_pw");
		
		
		
	}
}
