package b_operation;

public class Operation_01 {
	public static void maon(String[] args) {
		
		/*
		1. 연산자 기본
		
		- 단항 연산자
		 : ++, --, +, -, ~, !(not), (타입) <- cast연산자
		 
		- 이항 연산자
		 : 산술 연산자
		 	-> 		+, -, *, /, %, <<, >>, >>>(shift연산자)
		 : 비교 연산자
		 	->		 <, >, <=, >=, ==, !=, instanceof
		 : 논리 연산자
		 	-> 		&, |, ^, &&, ||
		 	
		- 삼항연산자
		 : __?__ :__
		 
		- 대입연산자
		 : =, op=
		 
		 
		 2. 연산우선순위
		  - 단항 > 이항 > 삼항 > 대입
		  - 산술 > 비교 > 논리 > 대입
		  
		
		
		
		
		
		
		*/
	}
}
