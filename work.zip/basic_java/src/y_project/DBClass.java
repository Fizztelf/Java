package y_project;

import java.util.Vector;

public class DBClass {		//테이블스테이스
	
	private Vector<ProductVO> proList = new Vector<>();	//물품들을 저장함

	public boolean addProduct(String name, int price) {
		ProductVO pb1 = new ProductVO(name, price);
		boolean result = proList.add(pb1);
		
		
		
		
		return result;
	}
	
	
	
}
